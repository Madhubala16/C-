﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            Converter f = new Converter(12);
            Converter m = new Converter(21);
            Console.WriteLine(f.Convert(30));
            Console.WriteLine(f.Convert(10));
            Console.WriteLine(f.Convert(m.Convert(12)));
            Console.ReadKey();
        }
    }
    public class Converter
    {
        int ratio;
        public Converter(int URatio)
        {
            ratio = URatio;
        }
        public int Convert(int unit)
        {
            return unit * ratio;
        }
    }
}
