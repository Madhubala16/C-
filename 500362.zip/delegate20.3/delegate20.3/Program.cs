﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate20._3
{
    class Program
    {
        delegate int MyDelegate(int i, int j);

        static void Main(string[] args)
        {
            MyDelegate del = (int i,int j)=> { return i + j; };
            //or MyDelegate del=(i,j)=> i+j;

            var result = del(5, 7);
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}
