﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "a" + 5; // a5
            /*string escaped = "First Line\nSecond Line";
            string verbatim = @"First Line
                                Second Line";*/
            //  string a = "Here's a tab:\t";
            //Console.WriteLine(escaped==verbatim);
            Console.WriteLine(s);
            Console.ReadKey();
        }
    }
}
