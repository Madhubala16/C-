﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrayexception
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[3];
    
            arr[3] = 1;//bounds checking
            Console.WriteLine("{0}", arr[1]);
            Console.ReadKey();
        }
    }
}
