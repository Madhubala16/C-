﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 8;
            Foo(ref x); // Ask Foo to deal directly with x
            Console.WriteLine("main value:"+x); // x is now 9
            Console.ReadKey();
        }
        static void Foo(ref int p)
        {
            p = p + 1; // Increment p by 1
            Console.WriteLine("foo value:"+p); // Write p to screen
        }
    }
}
