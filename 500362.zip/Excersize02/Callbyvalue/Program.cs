﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Callbyvalue
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 8;
            Foo(x); // Make a copy of x
            Console.WriteLine("in main"+x); // x will still be 8
            Console.ReadKey();
        }
        static void Foo(int p)
        {
            p = p + 1; // Increment p by 1
            Console.WriteLine("In foo:"+p); // Write p to screen
        }
    }
}
