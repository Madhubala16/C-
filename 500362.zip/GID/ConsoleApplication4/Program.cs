﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIDlist
{
    class Program
    { 
        static void Main(string[] args)
        {
            int rn;
            List<int> list = new List<int>();
            Console.WriteLine("Enter the number of Associate:");
            int n = int.Parse(Console.ReadLine());
            Random r = new Random();
            Console.WriteLine("Enter the GID number:");
            for (int i = 0; i < n; i++)
            {
                int GID = int.Parse(Console.ReadLine());
                list.Add(GID);
                  do
                    rn = r.Next(1, n);
                while (list.Contains(rn));

                list.Add(rn);
            }
            Console.WriteLine($"The Associate number ");
            Console.WriteLine($"Corresponding system number ");
            list.ForEach(Console.WriteLine);
            Console.ReadKey();
        }
    }
}