﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @interface
{
    class Zookeeper
    {
        static void Main(string[] args)
        {
        }
    }
    interface IAnimal
    {
        int ID { get; set; }
        void eat();
        //void talk();
    }
    interface Ipet
    {
        void kiss();
    }
    class cat: IAnimal,Ipet
    {
        public int ID { get; set; }
        public void talk()
        { }
    }
    class dog : IAnimal
    {
        public void talk()
        { }
    }
}
