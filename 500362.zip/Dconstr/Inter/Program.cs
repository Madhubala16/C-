﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inter
{
    class Employee
    {
        static void Main(string[] args)
        {
            int ch;
            Console.WriteLine("Enter ur choice");
            Console.WriteLine("1.Salary Employee\n 2.Contract Employee");
            int.TryParse(Console.ReadLine(), out ch);
            switch (ch)
            {
                case 1:
                    {
                        SalEmp emp1 = new SalEmp();
                        emp1.getValues();
                        emp1.Getdetails();
                        emp1.iPrivilege();
                        break;
                    }
                case 2:
                    {
                        ConEmp emp2 = new ConEmp();
                        emp2.getValues();
                        emp2.Getdetails();
                        break;
                    }
             }
            Console.ReadKey();
        }
    }

    public interface iPerson
    {
        void Getdetails();
    }
    public interface iPrivilege
    {
        void iPrivilege();
    }
    public class SalEmp :  iPerson , iPrivilege
    {
        public int ID;
        public string Name;
        public string emailID;
        public void getValues()
        {
            Console.WriteLine("Enter Your id");
            int.TryParse(Console.ReadLine(), out ID);
            Console.WriteLine("Enter your Name");
            Name = Console.ReadLine();
            Console.WriteLine("Enter your Email");
            emailID = Console.ReadLine();
        }
        public void Getdetails()
        {
            Console.WriteLine("I am "  +Name);
        }
        public void iPrivilege()
        {
            Console.WriteLine("And I am in the club");
        }
    }

    public class ConEmp :  iPerson
    {
        public int ID;
        public string Name;
        public string emailID;
        public void getValues()
        {
            Console.WriteLine("Enter Your id");
            int.TryParse(Console.ReadLine(), out ID);
            Console.WriteLine("Enter your Fname");
            Name = Console.ReadLine();
            Console.WriteLine("Enter your Email");
         }
        public void Getdetails()
        {
            Console.WriteLine("I am " + Name);
        }
    }
}
