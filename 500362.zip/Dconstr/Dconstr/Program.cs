﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dconstr
{
    class employee
    {
        static void Main(string[] args)
        {
            public void SayHello()
        {
            Console.WriteLine("hi {0} {1}",)
        }
        }
    }
}
class salaryemp : employee
    {

}

class contractemp : 