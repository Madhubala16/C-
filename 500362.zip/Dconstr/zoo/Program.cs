﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace zoo
//{
//    class Zookeeper
//        static void Main(string[] args)
//    {
//        cat c = new cat();
//        dog d = new dog();
            
 
//            abstract class Animal
//        {
//            public void eat() { }
//            public abstract void talk();
//        }
//    Conso
      
//    }

//    class cat : Animal
//    {
        
//        public override void talk()
//        { }
//    }
//    class dog : Animal
//            {
       
//        public override void talk()
//        { }
//    }
//}



