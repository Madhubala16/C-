﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            playSimpleSound();
            Console.ReadKey();
        }
        public static void playSimpleSound()
        {
            SoundPlayer simpleSound = new SoundPlayer(@"c:\Windows\Media\Alarm01.wav");
            simpleSound.Play();
        }
    }
}
