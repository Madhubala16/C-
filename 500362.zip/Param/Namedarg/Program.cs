﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Namedarg
{
    class Program
    {
        static void Main(string[] args)
        {
            Foo();
            test();
        }

        private static void Foo(int x, int y)
        {
            Console.WriteLine(x + ", " + y);
        }

        private static void test()
        {
            Foo(x: 1, y: 2);
        }
    }
}
