﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    delegate int MyDelegate(int i, int j);//declaration of delegate

    class Program
    {
        static void Main(string[] args)
        {
            int i = 15;
            int j = 7;
            MyDelegate del = sum;//function directly to ptr,pts 
           // MyDelegate del1 = sub;
            
            int result = del(i, j); //invoke the func
           // int result1 = del1(i, j);

            Console.WriteLine("result:" + result);
            Console.ReadKey();
        }
        private static int sum (int i,int j)
        {
            return i + j;
        }

        private static int sub(int i,int j)
        {
            return i - j;
        }
    }
}
