﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    delegate void MyDelegate(int i, int j);//declaration of delegate

    class Program
    {
        static void Main()
        {
            int i = 15;
            int j = 7;
            MyDelegate del = sum;//function directly to ptr,pts 
                                 // MyDelegate del1 = sub;
            del += sub;
            del(i, j); //invoke the func
            Console.ReadKey();
        }
        private static void sum(int i, int j)
        {
            Console.WriteLine($"The sum is { i + j }");
        }

        private static void sub(int i, int j)
        {
            Console.WriteLine($"The Subtarction is {i - j}");
        }
    }
}

