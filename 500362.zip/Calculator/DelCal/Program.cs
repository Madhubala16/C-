﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    delegate int MyDelegate(int i, int j);

    class Program
    {
        static void Main(string[] args)
        {
            displaymenu();
            
            int choice = GetInt("enter ur choice");
            int i = GetInt("enter 1st no");
            int j = GetInt("enter 2nd no");

            int result = 0;
            MyDelegate del = sum;
            del += sub;
            del += Mul;
            del += div;
            del(i, j);
            switch (choice)
            {
                case 1: result = sum(i,j); break;
                case 2: result = sub(i,j); break;
                case 3: result = Mul(i,j); break;
                case 4: result = div(i,j); break;
            }

            Console.WriteLine(result);
            Console.ReadKey();
        }

        private static int sum(int i, int j)
        {
            Console.WriteLine($"The sum is ");
            return (i + j);
        }

        private static int sub(int i, int j)
        {
            Console.WriteLine($"The Subtarction is ");
            return (i - j);
        }

        private static int Mul(int i, int j)
        {
            Console.WriteLine($"The Mul is ");
            return (i * j);
        }

        private static int div(int i, int j)
        {
            Console.WriteLine($"The Div is ");
            return (i / j);
        }

        private static int GetInt(string v)
        {
            int val;
            while (true)
            {
                Console.WriteLine(v);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error! re-try");
                }
            }
            return val;
        }


        private static void displaymenu()
        {
            string[] menuoptions = { "1.Add", "2.Sub", "3.Mul", "4.Div" };
            foreach (String item in menuoptions);
        }
    }
}
