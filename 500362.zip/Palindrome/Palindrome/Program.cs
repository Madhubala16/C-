﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
                string s, revs = "";
                Console.WriteLine(" Enter the string");
                s = Console.ReadLine();
                for (int i = s.Length - 1; i >= 0; i--) //String Reverse
                {
                    revs += s[i].ToString();
                }
                if (revs == s) // Checking whether string is palindrome or not
                {
                    Console.WriteLine("String is Palindrome{0}", s);
                }
                else
                {
                    Console.WriteLine("String is not Palindrome {0}", s);
                }
                Console.ReadKey();
            }
        }
}