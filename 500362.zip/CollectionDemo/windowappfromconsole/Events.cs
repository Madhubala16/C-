﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;


namespace windowappfromconsole
{
    class Events
    {
        [STAThread]
        static void Main(string[] args)
        {
            Window window = new Window();
            window.Height = 500;
            window.Width = 700;
            window.Title = "My first WPF";
           

            Button btn = new Button();
            btn.Height = 23;
            btn.Width = 75;
            btn.Content = "Click";
            btn.Click += (s,e)=> { MessageBox.Show("Hello world"); };

            window.Content = btn;

            Color color = new Color();
            color.R = 255;
            color.G = 0;
            color.B = 0;
            color.A = 255;
            
            SolidColorBrush SCB = new SolidColorBrush();
            SCB.Color = color;
            window.Background = SCB;

            Application app = new Application();
            app.Run(window);
        }

      /*  private static void Btn_Click(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }*/
    }
}
