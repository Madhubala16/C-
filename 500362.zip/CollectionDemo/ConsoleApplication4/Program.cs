﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static List<Employee> employees;
        static void Main(string[] args)
        {
            List<Employee> employees = new List<Employee>
            {
                new Employee {Id= 1, name="john"}
            };
            int Id = 0;

            Display();
            DisplayById(Id);
            InsertEmployee();
            UpdateEmployee(Id);
            DelEmploye(Id);
        }

        private static void DelEmploye(int id)
        {
            throw new NotImplementedException();
        }

        private static void UpdateEmployee(int id)
        {
            throw new NotImplementedException();
        }

        private static void InsertEmployee()
        {
            throw new NotImplementedException();
        }

        private static void DisplayById(int id)
        {
            
        }

        private static void Display()
        {
           foreach(var item in employees)
        {
                Console.WriteLine($"{item.Id}:{item.name}");
        }
        }
    }
}
