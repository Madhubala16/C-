﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Employee
    {
        internal object name;

        public int ID { ge; set; }
        public object Id { get; internal set; }

        public string
    }
}
