﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example
{
    class Program
    {
        static void Main(string[] args)
        {
            List<employee> emp = new List<employee>();
            emp.Add(new employee { ID = 1, name = "madhu" });
            emp.Add(new employee { ID = 2, name = "bala" });
            method1(emp);
            method2(emp);
            Console.ReadLine();

        }
        private static void method1(IEnumerable<person>emp)
        {
            foreach(var emps in emp)
            {
                Console.WriteLine($" {emps.ID}{ emps.name}");
            }
        }
        private static void method2(IEnumerable<person>emp)
        {
            Console.WriteLine("hiii");
        }
        
    }
    class person
    {
        
        public int ID { get; set; }
        public string name { get; set; }
    }
    class employee:person
    {
        public int ID { get; set; }
        public string name { get; set; }
    }
}
