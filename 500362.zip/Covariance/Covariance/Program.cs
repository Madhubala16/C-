﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Covariance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }
            class Animal { }
        class Bear : Animal { }
        class Camel : Animal { }
        public class Stack<T> // A simple Stack implementation
        {
            int position;
            T[] data = new T[100];
            public void Push(T obj) => data[position++] = obj;
            public T Pop() => data[--position];
        }
    }
    }

