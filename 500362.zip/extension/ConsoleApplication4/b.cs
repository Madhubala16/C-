﻿namespace ConsoleApplication4
{
    public class b
    {
    }
}