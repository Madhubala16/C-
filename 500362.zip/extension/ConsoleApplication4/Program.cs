﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            A ad = new A();
            B bd = new B();
            ad.add(7,5);
            //bd.Sub(7, 5);
            bd.add(11, 2);
            Console.ReadKey();
        }
     
    }
    class A
    {
        int a, b;
        public virtual void add(int i,int j)
        {
            a = i;
            b = j;
            Console.WriteLine("ADD:{0}", a + b);
        }

    }
    class B :A
    {
        int a, b;
        public override void add(int i,int j)
        {
            a = i;
            b = j;
            Console.WriteLine("Sub:{0}", a + b);
        }

    }
}
