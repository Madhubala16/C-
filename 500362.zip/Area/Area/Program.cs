﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area
{
    class Shape
    {
        static void Main(string[] args)
        {
           // Triangle T = new Triangle(10, 20);
            Rectangle R = new Rectangle(10, 5);
           // T.TArea();
            R.RArea();
            //public void set(double i, double j)
            //{
            //    double a, b;
            //    double.TryParse(Console.ReadLine(), out a);
            //    double.TryParse(Console.ReadLine(), out b);
            //}
            Console.ReadKey();
        }
    }
    //class Triangle : Shape
    //{
    //    int b, h;
    //       public Triangle(int breath,int height)
    //    {
    //        breath = b;
    //        height = h;
    //    }      
    //    public void TArea()
    //    {
    //         Areaoftri = .5 * b * h;
    //        Console.WriteLine($"Area of Triangle:{ 0.5 * b * h}");
    //    }      
    //}
    class Rectangle: Shape
    {
        int l, h;
        public Rectangle(int length, int height)
        {
            l=length ;
            h=height;
        }
        public void RArea()
        {
            int AreaofRec = l * h;
            Console.WriteLine($"Area of Rectangle:"+ AreaofRec);
        }
    }
}
