﻿namespace BankApp
{
    interface IROI
    {
        void GetRateOfInterest(long a);
    }
}
