﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            double a = 98, b = 0;
            double result=0;

            try
            {
                result = SafeDivision(a, b);
                Console.WriteLine("{0} divided by {1}={2}", a, b, result);
            }
            catch(DivideByZeroException e)
            {
                Console.WriteLine("Attempted divide by zero");
            }
            Console.ReadKey();
        }

        private static double SafeDivision(double a, double b)
        {
            if (b == 0)
                throw new System.DivideByZeroException();
            return a / b;
        }
    }
}
