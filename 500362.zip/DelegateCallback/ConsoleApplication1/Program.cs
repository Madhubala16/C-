﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    delegate int MyDelegate(); 
    class Program
    {
        private static MyDelegate DispalyResult;

        static void Main(string[] args)
        {
            int i = 35;
            int j = 7;
            MyDelegate callback = DispalyResult;
            sum(i, j, callback);
        }
        private static void sum(int i,int j,MyDelegate callback)
        {
            int result = i + j;
            callback($"The sum is{result}");
        }
        public static void DisplayResult(string message)
        {
            Console.WriteLine(message);
        }
    }
}
