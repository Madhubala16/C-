﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyNamespace
{

    class MyClass
    {
        static long acc_num;
        static void Main(String[] args)
        {


            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 12)
            {
                acc_num = Convert.ToInt64(w);

            }
            Console.WriteLine(acc_num);

            Console.ReadLine();


        }


    }
}