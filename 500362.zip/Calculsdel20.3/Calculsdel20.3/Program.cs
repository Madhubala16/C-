﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculsdel20._3
{
    class Program
    {
        private static int result;

        delegate int MyDelegate(int i, int j);
        static void Main(string[] args)
        {
            int ch;
            int.TryParse(Console.ReadLine(), out ch);
          
            switch (ch)
            {
                case 1:
                    MyDelegate del = (i, j) => i - j;
                    var result = del(7, 5);
                    Console.WriteLine(result);
                    break;
                case 2:
                    MyDelegate del = (i, j) => i - j;
                    result = del(7, 5);
                    Console.WriteLine(result);
                    break;
            }
            Console.WriteLine(result);
        }
    }
}
