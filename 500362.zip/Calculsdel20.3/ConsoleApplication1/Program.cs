﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    static class Myextension
    {
        public static void SayHello(this Employee e)
        {
            Console.WriteLine($"Hi I am{e.Id}{e.Name}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee e = new Employee(Id=7,Name="booll");
            e.SayHello
        }
    }
    class Employee
    {

    }
}
