﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericDel
{
    class product
    {

    }
    class person
    {
        public int ID { get; set; }
        public string name { get; set; }
        public void 
    }
    class employee:person
    {

    }
    class manager:person
    {

    }
    class Program
    {
        static void Main(string[] args)
        {
            product p = new product();
            employee e = new employee { ID = 1, name = "lee" };
            manager m = new manager { ID = 1, name = "leo" };
            SayHello<employee>(e);
            SayHello<employee>(m);
            SayHello<employee>(p);
        }
        private static void SayHello<T>(T t)
        {
            Console.WriteLine(t.GetType());//comes from obj type
            Console.WriteLine("HelloWorld");
        }
    }
}
