﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Threading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main method");
            LongMethod();
            for(int i=0;i<10;i++)
            {
                Console.WriteLine($"Inside main method{i} times");
            }


            Console.WriteLine("main end");
            Console.ReadKey();



        }
        static void LongMethod()
        {
            Console.WriteLine("long method");

            for (int i = 0; i < 20; i++)
            {
                Console.WriteLine($"Inside long method{i} times");
            }
            Console.WriteLine("long end");
        }
    }
}
