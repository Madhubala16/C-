﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Threadss
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main method");
            Thread th = new Thread(new ThreadStart(LongMethod));
            th.Start();

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Inside main method{i} times");
                Thread.Sleep(3000);
            }
            Console.WriteLine("main end");
            Console.ReadKey();
        }
        static void LongMethod()
        {
            Console.WriteLine("long method");

            for (int i = 0; i < 20; i++)
            {
                Console.WriteLine($"Inside long method{i} times");
                Thread.Sleep(3000);
            }
            Console.WriteLine("long end");
        }
    }
}

