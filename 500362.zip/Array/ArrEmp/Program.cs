﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrEmp
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice = GetInt("enter ur choice");
            List<employee> emps = new List<employee>
            {
                new employee {ID=GetInt(),name=GetName()},
                new employee {ID=GetInt(),name=GetName()},
                new employee {ID=GetInt(),name=GetName()}
            };

            foreach (var item in emps)
            {
                Console.WriteLine($"{item.ID}:{item.Name}");
            }

            switch (choice)
            {
                case 1:
                    employee el = new employee();
                    el.AddFunc();
                    break;
                case 2:
                    employee e2 = new employee();
                    e2.Disp();
                case 3:
                    return;
            }
    }

        private static String GetName()
        {
            
        }

        //Getting Input
        private static int GetInt(string v)
        {
            int val;
            while (true)
            {
                Console.WriteLine(v);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error! re-try");
                }
            }
            return val;
        }

    }
}
