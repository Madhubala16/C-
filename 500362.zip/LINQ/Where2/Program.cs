﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Where2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<{ Product > products = GetProductList();
                var soldOutProducts =
                    from p in products
                    where p.UnitsInStock == 0
                    select p;
                Console.WriteLine("Sold out products:");
                foreach(var product in soldOutProducts)
                {
                    Console.WriteLine("{0}is sold out!", product.ProductName);
                }
        }
    }
}
