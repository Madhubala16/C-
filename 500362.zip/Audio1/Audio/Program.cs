﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;

namespace Audio
{
    class Program
    {
        int i;
        static void Main(string[] args)
        {
            int i;
            Console.ReadLine();
            if (i < 10)
                Console.WriteLine("value:" + i);
            else
                playSimpleSound();
            Console.ReadKey();
        }

        private static void playSimpleSound()
        {
            SoundPlayer simplesound = new SoundPlayer(@"c:\Windows\Media\Alarm01.wav");
            simplesound.Play();
        }
    }
    
}
