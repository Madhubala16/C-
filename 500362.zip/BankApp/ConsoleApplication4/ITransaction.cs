﻿namespace BankApp
{
    interface ITransaction
    {
        void TransferAmount();
    }
}
