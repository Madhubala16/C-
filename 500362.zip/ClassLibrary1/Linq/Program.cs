﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            List<int> results = new List<int>();

            foreach(var item in nums)//filtering 
            {
                if(item %2!=0)
                {
                    results.Add(item);
                }
            }
            foreach(var item in results)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
        }
    }
}
