﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    public class InsuranceForIndividual : InsurancePolicyEssentials, IGetInstallmentDetails
    {
        public int ROI { get; set; }

        public override void AddNewCustomer()
        {
            Console.WriteLine("Enter policy name");
            tmppolicyname = Console.ReadLine();
            Console.WriteLine("Enter customer name");
            CustomerName = Console.ReadLine();
            Console.WriteLine("Enter policy amount");
            amount = Convert.ToInt32(Console.ReadLine());
            years = 5;
            DateofInsurance = DateTime.Today;
            MaturityDateofThePolicy = DateTime.Today.AddYears(4);
            MaxCoverageLimit = 40000000;

            Console.WriteLine("The policy name:{0}", tmppolicyname);
            Console.WriteLine("The policy number:{0}",PolicyNumber);
            Console.WriteLine("Policy holder's name:{0}",CustomerName);
            Console.WriteLine("The Policy amount:{0}",amount);
        }

        public override void EditCustomerDetails()
        {
            Console.WriteLine("Enter the Policy number");
            long numcheck = long.Parse(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.Iini)
            {
                count++;
                if (item.PolicyNumber == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.CustomerName);
                    Console.ForegroundColor=ConsoleColor.Magenta;
                    Console.WriteLine("enter\n1.to change name of customer\n2.to change policy amount\n3.to change no.of plan years");
                    Console.ResetColor();
                    int a = Convert.ToInt16(Console.ReadLine());
                    switch (a)
                    {
                        case 1:
                                Console.WriteLine("Customer name:"+item.CustomerName);
                                Console.WriteLine("Enter the new name");
                                item.CustomerName = Console.ReadLine();
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("Your username is modified successfully");
                                Console.WriteLine("AccountName:{0}", item.CustomerName);
                                Console.ResetColor();
                            break;
                        case 2:
                            Console.WriteLine("Policy amount:" + item.amount);
                            Console.WriteLine("Enter the new policy amount");
                            item.amount = int.Parse(Console.ReadLine());
                            Console.ForegroundColor = ConsoleColor.Green;
                            while (item.amount <= MaxCoverageLimit)
                                item.amount = item.amount;
                            Console.WriteLine("The policy amount is modified successully");
                            Console.WriteLine("Policy period:{0}", item.amount);
                            Console.ResetColor();
                            break;
                        case 3:
                            Console.WriteLine("Period of Policy:"+item.years);
                            Console.WriteLine("Enter the new no .of years ");
                            item.years = Convert.ToInt32(Console.ReadLine());
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Your Policy period is modified successfully");
                            Console.WriteLine("Policy period:{0}",item.years);
                            Console.ResetColor();
                            break;
                    }
                }
                else if (count == Program.Iini.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }
        }

        public void GetHalfYearlyInstallmentDetails()
        {
            ROI = 2;
            double am;
            am = amount / 6;
            am += am * 0.02;
            Console.WriteLine("Half yearly installment cost is " + am);
        }

        public override void GetPolicyDetails()
        {
            Console.WriteLine("Enter the Policy number");
            long numcheck = long.Parse(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.Iini)
            {
                count++;
                if (item.PolicyNumber == numcheck)
                {
                    Console.WriteLine("Policy Number:{0}", item.PolicyNumber);
                    Console.WriteLine("Customer Name:{0}", item.CustomerName);
                   // Console.WriteLine("Policy Name:{0}",item.PolicyName);
                    Console.WriteLine("Maturity year:{0}", item.years);
                    break;
                }
                else if (count == Program.Iini.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }
        }

        public void GetYearlyInstallmentDetails()
        {
            ROI = 2;
            double am;
            am = amount;
            am += am * 0.01;
            Console.WriteLine("yearly installment cost is " + am);
        }

        public void MonthlyInstallmentDeatils()
        {
            ROI = 2;
            double am;
            am = amount / 12;
            am += am * 0.02;
            Console.WriteLine("Monthly installment cost is " + am);
        }

        public void ExtraFeatures()
        {
            Console.WriteLine("Rate of interest is 2 % per year");
            Console.WriteLine("maturity date is 4 years");
            Console.WriteLine("policy amount is Rs.500 only");
        }

        
    }
}
