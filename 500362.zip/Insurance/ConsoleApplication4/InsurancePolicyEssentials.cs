﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    public abstract class InsurancePolicyEssentials
    {
        public readonly string PolicyName;
        public string CustomerName;
        public int Amount;
        public int years;
        public long PolicyNumber;

        //InsurancePolicyEssentials(string tmppolicyname)
        //{
        //    PolicyName = tmppolicyname;
        //}

        public InsurancePolicyEssentials()
        {
            this.PolicyNumber = genRandomnum();
        }

        long genRandomnum()
        {
            long pol_num = 0;
            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 12)
            {
                pol_num = Convert.ToInt64(w);
            }
            return pol_num;
        }

        public int amount;
        public DateTime DateofInsurance;
        public DateTime MaturityDateofThePolicy;
        public int MaxCoverageLimit;
        public string tmppolicyname;
        public abstract void AddNewCustomer();
        public abstract void EditCustomerDetails();
       
        public void RemoveCustomer(InsurancePolicyEssentials a)
        {
            a.CustomerName = null;
            a.amount = 0;
        }

        public void RemoveCustomer(InsurancePolicyEssentials b, int years)
        {
            b.CustomerName = null;
            b.amount = 0;
        }

        ~InsurancePolicyEssentials()
        {
            Console.WriteLine("Destructor is called");
        }

        public virtual void GetPolicyDetails()
        {
            Console.WriteLine(PolicyName);
            Console.WriteLine(CustomerName);
            Console.WriteLine(DateofInsurance);
            Console.WriteLine(MaturityDateofThePolicy);
        }
    }
}
