﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        public static List<InsuranceForIndividual> Iini = new List<InsuranceForIndividual>();
        public static List<InsuranceForFamily> Ifam = new List<InsuranceForFamily>();
        static void Main(string[] args)
        {
            string Confirm;
            do
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Welcome to the Life Insurance of Corporation");
                Console.WriteLine("1. Insurance for Individual \n2. Insurance for family");
                Console.ResetColor();
                Console.WriteLine("Enter the choice");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        displayMenu();
                        InsuranceForIndividual Iin = new InsuranceForIndividual();
                        accountOptions(Iin);
                        break;

                    case 2:
                        displayMenu();
                        InsuranceForFamily Ifa = new InsuranceForFamily();
                        accountOptions(Ifa);
                        break;
                }
                Console.WriteLine("Enter 'y' to continue");
                Confirm = Console.ReadLine().ToUpper();
            } while (Confirm == "Y");
            Console.ReadKey();
        }

        private static void accountOptions(InsuranceForIndividual obj)
        {
            Console.WriteLine("Enter the choice");
            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    obj.AddNewCustomer();
                    Iini.Add(obj);
                    break;
                case 2:
                    obj.EditCustomerDetails();
                    break;
                case 3:
                    obj.GetPolicyDetails();
                    break;
                case 4:
                    if ((obj.MaturityDateofThePolicy.Year - DateTime.Today.Year) != 0)
                        obj.RemoveCustomer(obj, obj.years);
                    else
                        obj.RemoveCustomer(obj);
                    break;
                case 5:
                    foreach (var i1 in Iini)
                    {
                        Console.WriteLine("enter customer name");
                        string nam = Console.ReadLine();
                        if (i1.CustomerName.Equals(nam))
                        {
                            i1.GetPolicyDetails();
                            i1.GetYearlyInstallmentDetails();
                            i1.GetHalfYearlyInstallmentDetails();
                            i1.MonthlyInstallmentDeatils();
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("no customer name found");
                            Console.WriteLine("enter y to add new customer or n to exit");
                            char n = Convert.ToChar(Console.ReadLine());
                            Console.ResetColor();
                            if (n.Equals('y') || n.Equals('Y'))
                                i1.AddNewCustomer();
                            else
                                break;
                        }
                    }
                    break;
                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
        }

        private static void accountOptions(InsuranceForFamily obj)
        {
            Console.WriteLine("Enter the choice");
            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    obj.AddNewCustomer();
                    Ifam.Add(obj);
                    break;
                case 2:
                    obj.EditCustomerDetails();
                    break;
                case 3:
                    obj.GetPolicyDetails();
                    break;
                case 4:
                    if ((obj.MaturityDateofThePolicy.Year - DateTime.Today.Year) != 0)
                        obj.RemoveCustomer(obj, obj.years);
                    else
                        obj.RemoveCustomer(obj);
                    break;
                case 5:
                    foreach (var i1 in Ifam)
                    {
                        Console.WriteLine("enter customer name");
                        string nam = Console.ReadLine();
                        if (i1.CustomerName.Equals(nam))
                        {
                            i1.GetPolicyDetails();
                            i1.GetYearlyInstallmentDetails();
                            i1.GetHalfYearlyInstallmentDetails();
                            i1.MonthlyInstallmentDeatils();
                        }
                        else
                        {
                            Console.WriteLine("no customer name found");
                            Console.WriteLine("enter y to add new customer or n to exit");
                            char n = Convert.ToChar(Console.ReadLine());
                            if (n.Equals('y') || n.Equals('Y'))
                                i1.AddNewCustomer();
                            else
                                break;
                        }
                    }
                    break;
                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
        }

        public static void displayMenu()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("1.Add new customer");
            Console.WriteLine("2.Edit the details");
            Console.WriteLine("3.Policy details");
            Console.WriteLine("4.Remove customer");
            Console.WriteLine("5.Installment Details");
            Console.ResetColor();
        }
    }
}
