﻿using System;
using System.Runtime.Serialization;

namespace ConsoleApplication4
{
    internal class AccountCloseException : Exception
    {
        public AccountCloseException()
        {
        }

        public AccountCloseException(string message) : base(message)
        {
        }

        public AccountCloseException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected AccountCloseException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}