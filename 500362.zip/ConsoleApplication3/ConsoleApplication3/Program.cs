﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emps = new List<Employee>();
            Method1(emps);
        }

        private static void Method1(List<person> emps)
        {
            //throw new NotImplementedException();
        }
    }
    class person
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    class Employee:person
    {

    }
}
