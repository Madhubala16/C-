﻿namespace BankCase
{
    public class Accounts
    {
    }
}