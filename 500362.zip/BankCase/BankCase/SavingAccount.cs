﻿using BankCase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCase
{
    public class SavingAccount : Accounts, ITransaction, IROI
    {
        int MaxwithdrawalAmount = 50000;
        int MaxDepositAmount = 50000;
        int minbal = 1000;

        public void getAccountDetails()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Bank.Accounts)
            {
                count++;
                if (item.AccountNumber == numcheck)
                {
                    Console.WriteLine("AccountNumber:{0}", item.AccountNumber);
                    Console.WriteLine("AccountName:{0}", item.UserName);
                    Console.WriteLine("AccountBalance:{0}", item.Balance);
                    break;
                }
                else if (count == Bank.Accounts.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }
        }

        public void GetRateOfInterest(long numcheck)
        {
            double simpleinterst = 0;
            foreach (var item in Bank.Accounts)
            {
                if (item.AccountNumber == numcheck)
                {
                    simpleinterst = item.Balance * 0.04 * 1;
                    item.Balance = item.Balance + (int)simpleinterst;
                    Console.WriteLine($"The Available balance in {item.AccountNumber} is {item.Balance}");
                }
            }
        }

        public void TransferAmount()
        {
            long fromaccount;
            long toaccount;
            Console.WriteLine("Enter the From account number");
            fromaccount = Convert.ToInt64(Console.ReadLine());
            int count = 0; int count1 = 0;
            foreach (var item in Bank.Accounts)
            {
                count++;
                if (item.AccountNumber == fromaccount)
                {
                    Console.WriteLine("Enter To account number");
                    toaccount = Convert.ToInt64(Console.ReadLine());


                    for (int i = 0; i < Bank.Accounts.Count; i++)
                    {
                        count1++;
                        if (Bank.Accounts[i].AccountNumber == toaccount)
                        {

                            Console.WriteLine("Enter the ammount to be transfered");
                            int amount = Convert.ToInt32(Console.ReadLine());
                            if (fromaccount != toaccount)
                            {
                                if (item.Balance > amount + minbal)
                                {
                                    item.Balance = item.Balance - amount;
                                    Bank.Accounts[i].Balance = Bank.Accounts[i].Balance + amount;
                                    Console.WriteLine("Balance is transferred successfully");
                                    Console.WriteLine($"The Available balance in the {Bank.Accounts[i].AccountNumber} is {Bank.Accounts[i].Balance }");
                                }
                                else
                                {
                                    Console.WriteLine("Insufficient balance to transfer");
                                }

                            }
                            else
                            {
                                Console.WriteLine("Transfer can be done between two different accounts");
                            }
                            break;

                        }
                        else if (count1 == Bank.Accounts.Count)
                        {
                            Console.WriteLine("Please enter the valid account number");
                        }

                    }
                    break;
                }
                else if (count == Bank.Accounts.Count)
                {
                    Console.WriteLine("Please enter the valid account number");
                }
            }
        }

        public void withdrawal()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Bank.Accounts)
            {
                count++;
                if (item.AccountNumber == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.UserName);
                    Console.WriteLine("Enter the amount to be Withdrawn");
                    int withdraw = Convert.ToInt32(Console.ReadLine());

                    if (withdraw < MaxwithdrawalAmount)
                    {
                        if ((item.Balance - withdraw) > minbal)
                        {
                            item.Balance -= withdraw;
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Amount is withdrawn successfully");
                            Console.ResetColor();
                        }

                    }
                    else if (count == Bank.Accounts.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Please entere the valid account number");
                        Console.ResetColor();
                    }

                }
            }
        }

        public void deposit()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Bank.Accounts)
            {
                count++;
                if (item.AccountNumber == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.UserName);
                    Console.WriteLine("Enter the amount to be deposited");
                    int deposit = Convert.ToInt32(Console.ReadLine());

                    if (deposit < MaxDepositAmount)
                    {
                        item.Balance += deposit;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Amount is deposited successfully");
                        Console.ResetColor();
                    }
                }
                else if (count == Bank.Accounts.Count)
                {
                    Console.WriteLine("Please enter the valid account number");
                }
            }
        }

        public void checkBalance()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Bank.Accounts)
            {
                count++;
                if (item.AccountNumber == numcheck)
                {
                    GetRateOfInterest(numcheck);
                    break;
                }
                else if (count == Bank.Accounts.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }
        }

        public void closeAccount()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Bank.Accounts)
            {
                count++;

                if (item.AccountNumber == numcheck)
                {
                    if (item.Balance == 0)
                    {
                        Bank.Accounts.Remove(item);
                    }
                    else
                    {
                        Console.WriteLine((" To close the Account the balance should be zero"));
                    }
                }
                else if (count == Bank.Accounts.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }

        }

        
    }
        
    }

