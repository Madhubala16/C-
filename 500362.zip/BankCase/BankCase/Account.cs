﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCase
{
    public abstract class Account
    {
        public readonly Int64 AccountNumber;
        public string UserName;
        public double Balance=0;
        private long acc_num;

        public static Account Accountmember { get; private set; }

        public Account(string UserName, double Balance)//constructor
        {
            this.UserName = UserName;
            this.Balance = Balance;
            Accnumcreate();
            AccountNumber = acc_num;
        }
        private void Accnumcreate()
        {
            long acc_num = 0;
            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 12)
            {
                acc_num = Convert.ToInt64(w);
            }
            Console.WriteLine(acc_num);
            Console.ReadLine();
        }

        public static Account EditAccount(List<Account> Accounts)
        {
        StartEditAccount:
            Console.Clear();
            Console.WriteLine("\t Edit Account");
            Console.WriteLine("\t ============");
            if (Accounts.Count > 0)
            {
                bool NotExist = true;
                Console.Write("Please Enter Your Account Number : ");
                Int64 accNumber = Convert.ToInt64(Console.ReadLine());
                foreach (Account acc in Accounts)
                {
                    if (acc.AccountNumber == accNumber)
                    {
                        NotExist = false;
                        Accountmember = acc;
                        break;
                    }
                }
                if (NotExist)
                {
                    Console.WriteLine("This Account Number Doesn't Exist in Our System. Press any key to continue");
                    Console.ReadKey();
                    goto StartEditAccount;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Your Account Details");
                    Console.WriteLine("Account Number : " + Accountmember.AccountNumber);
                    Console.WriteLine("User Name : " + Accountmember.UserName);
                    Console.WriteLine("Balance : " + Accountmember.Balance);
                    Console.Write("Updated User Name : ");
                    string username = Console.ReadLine();
                    Accountmember.UserName = username;
                    return Accountmember;
                }
            }
            else
            {
                Console.WriteLine("There is no Account Available in Our System. Press any key to continue...");
                Console.ReadKey();
            }
            return null;
        
    }
    }
}
