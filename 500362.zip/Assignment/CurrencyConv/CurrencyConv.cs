﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConv
{
    class CurrencyConv
    {
        private static double dollar;

        static void Main(string[] args)
        {
            displaymenu();
            int choice = GetInt("enter ur choice");
            dollar = GetInt("Enter the dollar value:");
            switch (choice)
            {
                case 1:
                    DollartoRupee();
                    break;
                case 2:
                    DollartoPounds();
                    break;
            }
            Console.ReadKey();
        }
        private static void DollartoPounds()
        {
            double result = dollar * 0.81;
            Console.WriteLine($"The value of British Pounds is:" + result);
        }
        private static void DollartoRupee()
        {
            double result = dollar * 65.48;
            Console.WriteLine($"The value of Indian Rupees is:" + result);
        }
        private static int GetInt(string v)
       {
            int val;
            while (true)
            {
                Console.WriteLine(v);
                if (int.TryParse(Console.ReadLine(), out val))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Error! re-try");
                }
            }
            return val;
        }
        private static void displaymenu()
        {
            string[] menuoptions = { "1.Dollar to Rupees conversion", "2.Dollar to Pounds conversion" };
            foreach (String item in menuoptions) ;
        }
    }
}
