﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reversenum
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            Reversenum = reverse();

        }

        public static object reverse()
        {
            int number;
            int rev = 0;
            if (number!=0)
            {
                rev = rev * 10;
                rev = rev + number % 10;
                number= number/10;
            }
            else
                return 
        }
    }
}
