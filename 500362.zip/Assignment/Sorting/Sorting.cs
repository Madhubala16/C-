﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sorting
{
    class Program
    {
        static void Main(string[] args)
        {
            Sort s = new Sort();
            s.bubbleSort();
            s.selectionSort();
            Console.WriteLine("Choose the choice of Sorting Method");
            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    s.bubbleSort();
                    break;
               
                case 2:
                    s.selectionSort();
                    break;

                case 3:
                    s.normalSort();
                    break;
             }
        }
    }
}

class Sort
{
    int[] a = { 4, 3, 1, 4, 6, 7, 5, 4, 32, 5, 26, 187, 8 };

    internal void bubbleSort()
    {
        for (int i = 0; i < a.Length; i++)
        {
            Console.WriteLine(a[i]);
        }
        for (int j = 0; j <= a.Length - 2; j++)
        {
            for (int i = 0; i <= a.Length - 2; i++)
            {
                if (a[i] > a[i + 1])
                {
                    int t = a[i + 1];
                    a[i + 1] = a[i];
                    a[i] = t;
                }
                else
                {
                    int t = a[i + 1];
                    a[i + 1] = a[i];
                    a[i] = t;
                }
            }
        }
        Console.WriteLine("The Sorted Array :");
        foreach (int aray in a)
            Console.Write(aray + " ");
        Console.ReadLine();
    }

    internal void normalSort()
    {
        if (choice == 1)
        {
            Array.Sort(a);
        }
        else
        {
            Array.Sort(a);
            Array.Reverse(a);
        }
        for (int i = 0; i < a.Length; i++)
        {
            Console.Write(" " + a[i]);
        }
    }

    internal void selectionSort()
    {
        for (int i = 0; i < a.Length; i++)
        {
            Console.WriteLine(a[i]);
        }
        int tmp, min_key;

        for (int j = 0; j < a.Length - 1; j++)
        {
            min_key = j;

            for (int k = j + 1; k < a.Length; k++)
            {
                if (a[k] < a[min_key])
                {
                    min_key = k;
                }
            }

            tmp = a[min_key];
            a[min_key] = a[j];
            a[j] = tmp;
        }

        Console.WriteLine("The Array After Selection Sort is: ");
        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine(a[i]);
        }
        Console.ReadLine();
    }
}
    
