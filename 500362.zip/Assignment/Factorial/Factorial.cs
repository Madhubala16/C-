﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorial
{
    class Factorial
    {
        static void Main(string[] args)
        {
            int i, f = 1, num;

            Console.WriteLine("Enter a number: ");
            int.TryParse(Console.ReadLine(), out num);

            for (i = 1; i <= num; i++)
                f = f * i;

            Console.WriteLine($"Factorial of {num} is: {f}");
            Console.ReadKey();
        }
    }
}
