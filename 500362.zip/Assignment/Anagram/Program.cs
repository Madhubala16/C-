﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace anagram_version2
{
    public class anagramTest
    {
        static void Main(String[] args)
        {
            string s1 = Console.ReadLine();
            string s2 = Console.ReadLine();
            bool isAnagram = IsAnagramOf(s1, s2);
            if (isAnagram == true)
            {
                Console.WriteLine("two strings are anagrams");

            }
            else
            {
                Console.WriteLine("two strings are  not anagrams");
            }
            Console.ReadLine();
        }
        public static bool IsAnagramOf(string stringA, string stringB)
        {
            var charsA = stringA.ToLower().ToArray().Where(c => c >= 'a' && c <= 'z');
            var charsB = stringB.ToLower().ToArray().Where(c => c >= 'a' && c <= 'z');
            return charsA.OrderBy(c => c).SequenceEqual(charsB.OrderBy(c => c));
        }
    }
}
