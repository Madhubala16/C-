﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reverseversion
{
    class Program
    {
        static void Main(string[] args)
        {
            // int[] tests = new int[5];//{ 12345 };
            Console.WriteLine("enter number");
            int n = Convert.ToInt32(Console.ReadLine());
            /*string s = n.ToString().Reverse();
            Console.Writeline("The reverse of the number is "+ s);*/
            foreach (char c in n.ToString().Reverse())
            {
                Console.Write(c);
            }
            Console.ReadLine();
        }
    }
}
